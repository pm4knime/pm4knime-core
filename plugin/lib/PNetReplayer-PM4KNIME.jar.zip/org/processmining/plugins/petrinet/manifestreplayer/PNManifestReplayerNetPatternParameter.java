/**
 * 
 */
package org.processmining.plugins.petrinet.manifestreplayer;

/**
 * @author aadrians
 * May 17, 2012
 *
 */
public class PNManifestReplayerNetPatternParameter extends AbstractPNManifestReplayerParameter {
	protected PNetPattern[] netPatterns;
	
	
}
