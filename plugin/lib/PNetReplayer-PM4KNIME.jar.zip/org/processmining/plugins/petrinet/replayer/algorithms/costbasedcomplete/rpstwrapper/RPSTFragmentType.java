/**
 * 
 */
package org.processmining.plugins.petrinet.replayer.algorithms.costbasedcomplete.rpstwrapper;

/**
 * @author aadrians
 *
 */
public enum RPSTFragmentType { POLYGONFORWARD, POLYGONBACKWARD, RIGID, BOND, TRIVIAL, UNDEFINED }
