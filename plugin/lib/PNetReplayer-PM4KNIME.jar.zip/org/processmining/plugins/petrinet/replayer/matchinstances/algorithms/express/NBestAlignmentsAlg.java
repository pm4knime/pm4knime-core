package org.processmining.plugins.petrinet.replayer.matchinstances.algorithms.express;

/**
 * Marker interface for an algorithm returning the N best algorithms
 * 
 * @author fmannhardt
 *
 */
public interface NBestAlignmentsAlg {

}
