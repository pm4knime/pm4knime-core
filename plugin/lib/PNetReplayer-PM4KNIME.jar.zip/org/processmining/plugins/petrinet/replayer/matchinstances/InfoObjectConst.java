/**
 * 
 */
package org.processmining.plugins.petrinet.replayer.matchinstances;

/**
 * @author aadrians
 * Apr 7, 2013
 *
 */
public enum InfoObjectConst { NUMREPRESENTEDALIGNMENT // number of alignments represented by a sample
	}
