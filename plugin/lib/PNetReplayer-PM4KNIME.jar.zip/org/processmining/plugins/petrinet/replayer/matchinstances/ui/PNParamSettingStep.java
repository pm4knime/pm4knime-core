/**
 * 
 */
package org.processmining.plugins.petrinet.replayer.matchinstances.ui;

import org.processmining.plugins.petrinet.replayer.ui.IParamSetting;


/**
 * @author arya
 * 
 */
public abstract class PNParamSettingStep extends
		PNReplayStep implements IParamSetting {
	private static final long serialVersionUID = 1812273645177889340L;

	public PNParamSettingStep() {}
}
