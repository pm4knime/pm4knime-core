/**
 * 
 */
package org.processmining.plugins.petrinet.replayer.matchinstances.ui;

import javax.swing.JPanel;

/**
 * @author arya
 * 
 * Abstract class for replay step required for PN replay algorithm
 */
public abstract class PNReplayStep extends JPanel {
	private static final long serialVersionUID = -2899039247220690270L;
}
