/**
 * 
 */
package org.processmining.plugins.petrinet.replayer.ui;

/**
 * @author aadrians
 *
 */
public interface IParamSetting {
	public Object getParameterValue(int paramVariableValIndex);
	
	public Object[] getAllParameters();

}
